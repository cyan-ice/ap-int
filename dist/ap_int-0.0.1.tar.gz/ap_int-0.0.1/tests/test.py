from functools import wraps
from asyncio import *
from ap_int import *

class test:
    n = 0

    def __init__(self, name, timeout):
        self._id, self.name, self.timeout = test.n, name, timeout

    def __call__(self, f):
        @wraps(f)
        async def wrapper():
            print(end=f'Test #{self._id}: {self.name}... ')
            try:
                if self.timeout is None:
                    f()
                else:
                    async with timeout(self.timeout):
                        await f()
                print('Passed')
            except TimeoutError:
                print('Failed: Timed Out')
            except:
                print('Failed')
        return wrapper

@test('Arithmetics', 1)
def add():
    a, b = Integer(114514), Integer(1919810)
    assert a + b == 2034324
    assert a - b == -1805296
    assert b - a == 1805296
    assert a * b == 219845122340
    assert a // b == 0
    assert b // a == 16

add()